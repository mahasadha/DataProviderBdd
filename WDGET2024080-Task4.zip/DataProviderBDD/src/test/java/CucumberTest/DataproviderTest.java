package CucumberTest;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.*;
import java.io.FileInputStream;
import java.io.IOException;

public class DataproviderTest {
	
    private static final String FILE_PATH = "D:\\TestData.xlsx"; 

    public static Object[][] getTestData(String sheetName) {
        Object[][] testData = null;
        try {
            FileInputStream file = new FileInputStream(FILE_PATH);
            Workbook workbook = WorkbookFactory.create(file);
            Sheet sheet = workbook.getSheet("Sheet1");

            int rowCount = sheet.getPhysicalNumberOfRows();
            int colCount = sheet.getRow(0).getLastCellNum();
            
            testData = new Object[rowCount - 1][colCount]; 

            for (int i = 0; i < rowCount - 1; i++) {
                Row row = sheet.getRow(i + 1); 
                for (int j = 0; j < colCount; j++) {
                    Cell cell = row.getCell(j);
                    testData[i][j] = cell != null ? cell.toString() : ""; 
                }
            }
            workbook.close();
            file.close();
            
        } catch (IOException | EncryptedDocumentException e) {
            e.printStackTrace();      
        }
        return testData;
    }
}
