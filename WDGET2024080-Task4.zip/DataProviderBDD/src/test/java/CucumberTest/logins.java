package CucumberTest;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class logins {
    private WebDriver driver;

    @BeforeClass
    public void setup() {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\vignesh\\Downloads\\chromedriver-win64\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.get("https://www.udemy.com/join/login-popup/");
    }

    @DataProvider(name = "loginData")
    public Object[][] getTestData() {
        return DataproviderTest.getTestData("D:\\TestData.xlsx");
    }

    @Test(dataProvider = "loginData")
    public void loginTest(String username, String password, String expectedResult) {
    	WebElement loginField = driver.findElement(By.xpath("//span[normalize-space()='Log in']"));
    	loginField.click();
        WebElement usernameField = driver.findElement(By.xpath("//input[@id='form-group--1']"));
        WebElement passwordField = driver.findElement(By.xpath("//input[@id='form-group--3']"));
        WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']//span[contains(text(),'Log in')]")); 

        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        loginButton.click();

        if (expectedResult.equals("be logged in successfully")) {
            WebElement dashboardElement = driver.findElement(By.xpath("//div[@class='user-profile-dropdown-module--dropdown-button-avatar--CffDQ ud-avatar ud-heading-sm']")); 
            Assert.assertTrue(dashboardElement.isDisplayed());
        } else {
            WebElement errorMessageElement = driver.findElement(By.xpath("//div[@data-purpose='safely-set-inner-html:auth:error']")); 
            Assert.assertTrue(errorMessageElement.isDisplayed());
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
